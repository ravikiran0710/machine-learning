#lab4 A6
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
data = pd.read_csv("ml_dataset.csv")
X = data[['alpha']].values
Y = data[['beta']].values
def scatter(X, y):
  classes = np.where(X + y > 10, 0, 1)

  X_class0 = X[classes == 0]
  y_class0 = y[classes == 0]

  X_class1 = X[classes == 1]
  y_class1 = y[classes == 1]

  plt.scatter(X_class0, y_class0, color = 'r', marker = 'o')
  plt.scatter(X_class1, y_class1,  color = 'b', marker = 'o')
  plt.title('scatter plot of class0 and class1')
  plt.show()
scatter(X, Y)
def k_knn1(X,Y,k):

  X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state = 42)
  train_data = np.column_stack((X_train, Y_train))


  classes = np.where(X_train + Y_train > 17.430859e-11, 1, 0)

  X_test_val = np.arange(0, 10.1, 0.1)
  Y_test_val = np.arange(0, 10.1, 0.1)

  X_test, Y_test = np.meshgrid(X_test_val, Y_test_val)

  test_data = np.column_stack((X_test.ravel(), Y_test.ravel()))


  knn = KNeighborsClassifier(n_neighbors=k)
  knn.fit(train_data, classes)

  test_pred = knn.predict(test_data)

  class0 = test_data[test_pred == 0]
  class1 = test_data[test_pred == 1]

  plt.scatter(class0[:, 0], class0[:, 1], color='blue', s=5, label='Class 0')
  plt.scatter(class1[:, 0], class1[:, 1], color='red', s=5, label='Class 1')

  plt.scatter(X_train, Y_train, c=classes, cmap='bwr', edgecolors='k', s=60)

  plt.xlabel('X')
  plt.ylabel('Y')
  plt.title('kNN Classification (k = 3)')
  plt.legend()
  plt.show()
k_knn1(X,Y,3)
k_knn1(X,Y,1)
k_knn1(X,Y,10)