# Lab 4 A4
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
def k_knn(k):
  X_train = np.random.randint(1, 11, size=20)
  Y_train = np.random.randint(1, 11, size=20)

  train_data = np.column_stack((X_train, Y_train))


  classes = np.where(X_train + Y_train > 10, 1, 0)

  X_test_val = np.arange(0, 10.1, 0.1)
  Y_test_val = np.arange(0, 10.1, 0.1)

  X_test, Y_test = np.meshgrid(X_test_val, Y_test_val)

  test_data = np.column_stack((X_test.ravel(), Y_test.ravel()))


  knn = KNeighborsClassifier(n_neighbors=k)
  knn.fit(train_data, classes)

  test_pred = knn.predict(test_data)


  class0 = test_data[test_pred == 0]
  class1 = test_data[test_pred == 1]

  plt.scatter(class0[:, 0], class0[:, 1], color='blue', s=5, label='Class 0')
  plt.scatter(class1[:, 0], class1[:, 1], color='red', s=5, label='Class 1')

  plt.scatter(X_train, Y_train, c=classes, cmap='bwr', edgecolors='k', s=60)

  plt.xlabel('X')
  plt.ylabel('Y')
  plt.title('kNN Classification (k = 3)')
  plt.legend()
  plt.show()
k_knn(3)