import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

X = np.random.randint(1, 11, size=(20, 2))
y = np.where(X[:, 0] + X[:, 1] > 10, 1, 0)


knn = KNeighborsClassifier()
param_grid = {
    'n_neighbors': [1, 3, 5, 7, 9]
}

grid_search = GridSearchCV(
    knn,
    param_grid,
    cv=5,
    scoring='accuracy'
)

grid_search.fit(X, y)

param_dist = {
    'n_neighbors': np.arange(1, 15)
}

random_search = RandomizedSearchCV(
    knn,
    param_distributions=param_dist,
    n_iter=5,
    cv=5,
    scoring='accuracy',
    random_state=42
)

random_search.fit(X, y)

print("GridSearch Best k:", grid_search.best_params_['n_neighbors'])
print("GridSearch Best Accuracy:", grid_search.best_score_)

print("RandomSearch Best k:", random_search.best_params_['n_neighbors'])
print("RandomSearch Best Accuracy:", random_search.best_score_)