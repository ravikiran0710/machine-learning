#lab 4 A 3
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
X = np.random.randint(1,11, size = 20)
y = np.random.randint(1, 11,size = 20)
def scatter(X, y):
  classes = np.where(X + y > 10, 0, 1)

  X_class0 = X[classes == 0]
  y_class0 = y[classes == 0]

  X_class1 = X[classes == 1]
  y_class1 = y[classes == 1]

  plt.scatter(X_class0, y_class0, color = 'r', marker = 'o')
  plt.scatter(X_class1, y_class1,  color = 'b', marker = 'o')
  plt.title('scatter plot of class0 and class1')
  plt.show()
scatter(X, y)