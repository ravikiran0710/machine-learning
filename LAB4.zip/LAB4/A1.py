#lab 4 A1
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score
)

data = pd.read_csv("ml_dataset.csv")

def knn(data, k):
    # Define the feature columns
    feature_columns = ['alpha', 'beta', 'beta_alpha_ratio', 'delta',
                       'gamma', 'rms', 'theta', 'variance']

    # Convert feature columns to numeric, coercing errors to NaN
    for col in feature_columns:
        data[col] = pd.to_numeric(data[col], errors='coerce')

    # Drop rows with NaN values introduced by coercion
    data.dropna(subset=feature_columns, inplace=True)

    X = data[feature_columns].values
    y_str = data['label'].values

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_str)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    f1 = f1_score(y_test, y_pred, average='weighted')

    cm = confusion_matrix(y_test, y_pred)

    return y_pred, accuracy, precision, recall, f1, cm, y_test

pred, acc, prec, rec, f1, cm, y_test = knn(data, 3)

print("===== KNN (k=3) ===Interpolator: ===")
print("Accuracy :", acc)
print("Precision:", prec)
print("Recall   :", rec)
print("F1-score :", f1)
print("\nConfusion Matrix:\n", cm)
print("\nClassification Report:\n")
print(classification_report(y_test, pred))

pred1, acc1, prec1, rec1, f11, cm1, y_test1 = knn(data, 1)

print("===== KNN (k=1) ===Interpolator: ===")
print("Accuracy :", acc1)
print("Precision:", prec1)
print("Recall   :", rec1)
print("F1-score :", f11)
print("\nConfusion Matrix:\n", cm1)
print("\nClassification Report:\n")
print(classification_report(y_test1, pred1))
