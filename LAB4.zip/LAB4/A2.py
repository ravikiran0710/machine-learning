#lab 4 A2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
data = pd.read_excel('Lab2 Session Data.xlsx', sheet_name = 'IRCTC Stock Price')

def convert_volume(volume_str):
    if isinstance(volume_str, str):
        volume_str = volume_str.strip()
        if 'M' in volume_str:
            return float(volume_str.replace('M', '')) * 1_000_000
        elif 'K' in volume_str:
            return float(volume_str.replace('K', '')) * 1_000
    return float(volume_str)

data['Volume'] = data['Volume'].apply(convert_volume)

X = data[['High', 'Low', 'Volume', 'Chg%']]
y = data[['Price']].values
def price_prediction(X, y):
  X_train, X_test, y_train,y_test = train_test_split(X,y, test_size=0.2, random_state=42)
  knn = KNeighborsRegressor(n_neighbors=3)
  
  knn.fit(X_train, y_train.ravel())
  y_pred = knn.predict(X_test)
  return y_test, y_pred

def MSC(data, pred):
  data = np.array(data).flatten()
  pred = np.array(pred).flatten()
  final = np.sum((data - pred) ** 2)
  return final/len(data)
def RMSC(data, pred):
  msc = MSC(data, pred)
  return np.sqrt(msc)
def MAPE(data, pred):
  data = np.array(data).flatten()
  pred = np.array(pred).flatten()
  abs_error = np.abs(data - pred)
  percentage_error = np.where(data != 0, abs_error / data, 0) 
  return 100 * np.mean(percentage_error)
def R2(data, pred):
  data = np.array(data).flatten()
  pred = np.array(pred).flatten()
  total_sum_of_squares = np.sum((data - np.mean(data)) ** 2)
  sum_of_squared_residuals = np.sum((data - pred) ** 2)
  if total_sum_of_squares == 0:
      return 1.0 if sum_of_squared_residuals == 0 else 0.0
  return 1 - (sum_of_squared_residuals / total_sum_of_squares)

Y, y_hat = price_prediction(X,y)
print(f"MSC: {MSC(Y, y_hat)}")
print(f"RMSC: {RMSC(Y, y_hat)}")
print(f"MAPE: {MAPE(Y, y_hat)}")
print(f"R2: {R2(Y, y_hat)}")